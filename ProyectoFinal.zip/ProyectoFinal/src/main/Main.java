package main;

import controlador.ControladorPrincipal;
import vista.VistaPrincipal;

public class Main {

    public static void main(String[] args) {
   
    	ControladorPrincipal cPrincipal =new ControladorPrincipal(new VistaPrincipal());
    }
}