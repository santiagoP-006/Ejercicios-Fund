module Clinica {

	requires java.desktop;
}